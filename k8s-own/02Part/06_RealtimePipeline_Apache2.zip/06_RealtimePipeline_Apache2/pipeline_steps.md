## Deployment on Kubernetes cluster using CI/CD

#### Prerequisites:
* Git, Linux, Jenkins, Docker, Docker Hub Account, Ansible, Kubernetes
* 3 EC2 Instances:
  * Jenkins (default-jre-jenkins)
  * Ansible (python-ansible-docker)
  * Webapp (Kubernetes Cluster)--> Docker + minikube